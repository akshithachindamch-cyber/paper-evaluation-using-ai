# utils/scoring.py
from .llm_evaluator import evaluate_answer

def calculate_score(
    similarity,
    faculty_keywords,
    model_keywords,
    student_text,
    max_marks,
    question_text,
    model_answer_text
):
    """
    LLM-FIRST scoring strategy:
    - LLM acts as the primary evaluator
    - Keywords & similarity act only as guardrails
    """

    # ────────────────────────────────────────────────
    # 1. Keyword coverage (GUARD METRIC, not judge)
    # ────────────────────────────────────────────────
    all_keywords = set(
        [k.strip().lower() for k in faculty_keywords] +
        [k.strip().lower() for k in model_keywords]
    )

    student_text_lower = student_text.lower()

    matched = sum(1 for kw in all_keywords if kw in student_text_lower)
    keyword_ratio = matched / len(all_keywords) if all_keywords else 1.0

    # ────────────────────────────────────────────────
    # 2. LLM-based evaluation (PRIMARY DECISION)
    # ────────────────────────────────────────────────
    try:
        llm_score, llm_reason = evaluate_answer(
            question=question_text,
            model_text=model_answer_text,
            student_text=student_text,
            max_marks=max_marks
        )
    except Exception as e:
        llm_score = 0.0
        llm_reason = f"LLM evaluation unavailable ({str(e)})"

    # Safety clamp
    llm_score = max(0.0, min(llm_score, float(max_marks)))

    final_score = llm_score
    decision_note = "Score primarily determined by conceptual LLM evaluation"

    # ────────────────────────────────────────────────
    # 3. GUARDRAIL PENALTY (only when answer is weak)
    # ────────────────────────────────────────────────
    if similarity < 0.4 and keyword_ratio < 0.3:
        penalty_cap = 0.4 * max_marks
        final_score = min(final_score, penalty_cap)
        decision_note = (
            "Penalty applied: low semantic relevance and insufficient factual grounding"
        )

    # Optional rounding (exam-friendly)
    final_score = round(final_score * 2) / 2  # rounds to nearest 0.5

    # ────────────────────────────────────────────────
    # 4. Explanation for transparency
    # ────────────────────────────────────────────────
    reason = (
        f"LLM evaluation: {llm_reason}\n"
        f"Keyword coverage: {keyword_ratio:.2f}, "
        f"Semantic similarity: {similarity:.2f}\n"
        f"Final decision: {decision_note}"
    )

    return final_score, list(all_keywords), reason
