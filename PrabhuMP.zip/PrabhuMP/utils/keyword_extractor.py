import re
import string
from collections import Counter
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Uncomment once if not downloaded
#nltk.download("stopwords")
#nltk.download("wordnet")

stop_words = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()

def extract_keywords(text, top_n=10):
    """
    Extracts meaningful keywords using
    tokenization + lemmatization + frequency.
    """
    text = text.lower()

    tokens = re.findall(r"\b[a-zA-Z]{3,}\b", text)

    processed = [
        lemmatizer.lemmatize(word)
        for word in tokens
        if word not in stop_words
        and word not in string.punctuation
    ]

    freq = Counter(processed)
    keywords = [word for word, _ in freq.most_common(top_n)]

    return keywords
