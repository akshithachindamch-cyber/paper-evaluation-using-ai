# test_llm.py
from llm_evaluator import evaluate_answer

score, reason = evaluate_answer(
    question="Explain what a binary tree is.",
    model_text="A binary tree is a tree data structure in which each node has at most two children...",
    student_text="Binary tree has nodes and two children.",
    max_marks=5
)

print(f"Score: {score}")
print(f"Reason: {reason}")