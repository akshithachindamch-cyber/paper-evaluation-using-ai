# utils/ocr.py
import os
import tempfile
from pdf2image import convert_from_bytes
from google.cloud import vision

client = vision.ImageAnnotatorClient()


def _ocr_image(image_path: str) -> str:
    with open(image_path, "rb") as f:
        content = f.read()

    image = vision.Image(content=content)
    response = client.document_text_detection(image=image)

    if response.error.message:
        raise RuntimeError(response.error.message)

    return response.full_text_annotation.text or ""


def extract_text(uploaded_file) -> str:
    """
    Extract text from:
    - image files (png, jpg, jpeg)
    - multi-page PDFs
    """

    if not uploaded_file or not uploaded_file.filename:
        return ""

    filename = uploaded_file.filename.lower()

    with tempfile.TemporaryDirectory() as tmp:
        full_text = ""

        # 🔁 IMPORTANT: reset pointer
        uploaded_file.seek(0)

        # IMAGE FILES
        if filename.endswith((".png", ".jpg", ".jpeg")):
            path = os.path.join(tmp, "page_1.png")
            uploaded_file.save(path)
            full_text = _ocr_image(path)

        # MULTI-PAGE PDF
        elif filename.endswith(".pdf"):
            pdf_bytes = uploaded_file.read()

            images = convert_from_bytes(
                pdf_bytes,
                dpi=200,
                fmt="png"
            )

            for i, img in enumerate(images, start=1):
                img_path = os.path.join(tmp, f"page_{i}.png")
                img.save(img_path, "PNG")
                full_text += _ocr_image(img_path) + "\n"

        else:
            raise ValueError("Unsupported file type")

        return full_text.strip()
