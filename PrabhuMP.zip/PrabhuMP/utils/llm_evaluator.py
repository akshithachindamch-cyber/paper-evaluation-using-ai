# utils/llm_evaluator.py
from openai import OpenAI
import os

# Initialize client (Hugging Face OpenAI-compatible router)
client = OpenAI(
    api_key=os.getenv("HF_TOKEN"),
    base_url="https://router.huggingface.co/v1",
)

def evaluate_answer(question, model_text, student_text, max_marks):
    """
    Evaluate student answer using a moderately lenient examiner approach.
    Returns: (score: float, reason: str)
    """

    prompt = f"""
    You are a fair and concept-focused university exam evaluator.

Your goal is to evaluate the student's understanding, not their ability to match exact wording.

Evaluation rules:
- Evaluate the student’s answer conceptually.
- Do NOT require exact keywords or phrasing.
- Reward correct understanding even if different terminology is used.
- Use keywords or model answer only as a reference, not a requirement.
- Minor grammar or spelling mistakes should not significantly reduce marks.
- Extra correct explanation should be rewarded, not penalized.
- Penalize only when the answer is conceptually incorrect, irrelevant, or misleading.

Question:
{question}

Model / ideal answer:
{model_text}

Student's answer:
{student_text}

Evaluation guidelines:
- Award partial credit for correct or relevant points, even if incomplete.
- Do not heavily penalize minor grammar issues or weak structure.
- Reward understanding and intent over perfect wording.
- Penalize only if the answer is clearly incorrect, irrelevant, or extremely shallow.
- If the answer only lists keywords with no explanation, limit marks but still award minimal credit.

Evaluate the answer out of {max_marks} marks based on:
- Relevance and correctness
- Coverage of key ideas
- Depth of understanding (even brief explanations count)
- Overall clarity

Output format (exactly this, nothing else):

Score: X
Explanation: short justification of the marks.
"""

    try:
        response = client.chat.completions.create(
            model="Qwen/Qwen2.5-7B-Instruct",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=180,
            temperature=0.2,   # slightly more flexible
            top_p=0.9,
        )

        text = response.choices[0].message.content.strip()

        # Parse response
        if "Score:" in text and "Explanation:" in text:
            score_part, explanation_part = text.split("Explanation:", 1)
            score_str = score_part.replace("Score:", "").strip()
            explanation = explanation_part.strip()

            try:
                score = float(score_str)
            except ValueError:
                score = 0.0
        else:
            score = 0.0
            explanation = "Unable to reliably parse evaluator response"

        # Safety clamp
        score = max(0.0, min(score, float(max_marks)))

        return round(score, 1), explanation

    except Exception as e:
        print(f"LLM API error: {str(e)}")
        return 0.0, f"Evaluation service unavailable ({str(e)})"
